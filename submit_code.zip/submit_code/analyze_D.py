#!/usr/bin/env python
###############################################################################
#####  Run calculate_D.py first, to calculate diffusivity (Dh)#################
###############################################################################
import numpy as np
import matplotlib.pyplot as plt
from scipy import stats

###############################################################################
######## confidence intervals #################################################
def ConfInter(x, y, slope, inter, xstar):
  N=len(x)
  Sy=(np.sum((y-(slope*x+inter))**2)/(N-2))**0.5
  return 1.96*Sy*(1./N+(xstar-np.mean(x))**2/(N-1)/(np.std(x))**2)**0.5

###############################################################################
######## load the soil properties read from NCSCD and WISE, corresponding to the sites
###############################################################################
ncscd_site=np.load(    'XX/INPUT/ncscd_sites.npy') #first dimension: 'SOCC30','SOCC100','SOCC200','SOCC300','histel_pct','histosol_pct','gelisol_pct','orthel_pct','othsoil_pct','turbel_pct','nonsoil_pct'
wise_site=np.load(     'XX/INPUT/wise_sites.npy') #first dimension: CF CF_std sand sand_std silt silt_std clay clay_std BD BD_std TAWC TAWC_std OC OC_std TOTN TOTN_std CNrt CNrt_std SOC SOC_std ; second dimention: 7 depths
wise_site_peat=np.load('XX/INPUT/wise_sites_peat.npy') #fraction of histosol
wise_depth=[0.2,0.2,0.2,0.2,0.2,0.5,0.5]

###############################################################################
######## analyze the relationship between Dh and soil properties ##############
###############################################################################
fig=plt.figure(figsize=(23.2,16.3))
###~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
yy0=np.nanpercentile(Dh,[5,25,50,75,95],axis=1)
iper1=1; iper2=3 # 25th 75th
yerr=np.array([yy0[2]-yy0[iper1],yy0[iper2]-yy0[2]]).reshape(2,263)
###~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
ax=fig.add_subplot(4,4,1)
xx1=np.sum(ncscd_site[1:4],axis=0)/10.
xx1[xx1==0]=np.nan
xx1[np.sum(ncscd_site[4:6],axis=0)>=50]=np.nan
###~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
wise=np.sum(np.transpose(wise_site,(1,2,0))*wise_depth,axis=2)/2. #integrate over the depth
tmp=np.where(wise_site_peat>50,np.nan,1) ; wise=wise*tmp
xx2=wise[18]*2 ; xx2[xx1==xx1]=np.nan #for SOC density 0-2m, the value (previously divided by 2m) is now multiplied by 2m
xx22=wise[18]*2 ; xx22[xx2==xx2]=np.nan
xx3=np.where(xx1==xx1,xx1,xx2)
###~~~~~~~~~~~~~~~~~~~~~~~
xstar=np.arange(0,105,1.)
###~~~~~~~~~~~~~~~~~~~~~~~
tmp=(yy0[2]==yy0[2])*(xx1==xx1)
slope,intercept,r_value,p_value,std_err = stats.linregress(xx1[tmp],yy0[2][tmp])
ystar=ConfInter(xx1[tmp], yy0[2][tmp], slope, intercept, xstar)
###~~~~~~~~~~~~~~~~~~~~~~~
tmp=(yy0[2]==yy0[2])*(xx3==xx3)
slope,intercept,r_value,p_value,std_err = stats.linregress(xx3[tmp],yy0[2][tmp])
ystar=ConfInter(xx3[tmp], yy0[2][tmp], slope, intercept, xstar)
ax.plot(xstar,xstar*slope+intercept,color='grey',lw=0.7,label='N='+str('%i' %np.sum(tmp))+' r='+str('%.2f' %r_value))
ax.plot(xstar,xstar*slope+intercept-ystar,color='grey',ls='--',lw=0.7)
ax.plot(xstar,xstar*slope+intercept+ystar,color='grey',ls='--',lw=0.7)
ax.fill_between(xstar,xstar*slope+intercept-ystar,xstar*slope+intercept+ystar,color='grey',alpha=0.3)
ax.plot(xstar,xstar*slope+intercept,lw=0,label='slope='+str(slope)+' interc='+str('%.2f' %intercept)+' p='+str('%.3f'%p_value))
###~~~~~~~~~~~~~~~~~~~~~~~
blue_color=[0/255.,51/255.,204/255.]
ax.errorbar(xx1,yy0[2],yerr=yerr,color='g',elinewidth=0.3,marker='x',markersize=8,mew=0.6,mfc='None',mec='g',lw=0,label='NCSCD')
ax.errorbar(xx2,yy0[2],yerr=yerr,color=blue_color,elinewidth=0.3,marker='o',markersize=8,mew=0.4,mfc='None',mec=blue_color,lw=0,label='WISE')
###~~~~~~~~~~~~~~~~~~~~~~~
ax.legend(loc=0,fontsize=8)
for label in ax.get_xticklabels():label.set_fontsize(15)
for label in ax.get_yticklabels():label.set_fontsize(15)
ax.set_xlabel('SOC (kgC/m2)', fontsize=15)
ax.set_ylabel('Dh', fontsize=15)
ax.set_ylim(0,1.75)
###~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
###~~~~~~ other properties ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
xlabels=['gravel (%vol)','sand (%weight)','silt (%weight)','clay (%weight)','bulk density (kg/dm3)','OC (%weight)','SOC density (kgC/m2)']
xind=[0,2,4,6,8,12,18]
for loop in range(len(xind)):
  ax=fig.add_subplot(4,4,5+loop)
  if xind[loop]==18: xx3=wise[xind[loop]]*2
  if xind[loop]!=18: xx3=wise[xind[loop]]*1
  tmp=(yy0[2]==yy0[2])*(xx3==xx3)
  slope,intercept,r_value,p_value,std_err = stats.linregress(xx3[tmp],yy0[2][tmp])
  ###~~~~~~~~~~~~~~~~~~~~~~~
  dv=(np.nanmax(xx3)-np.nanmin(xx3))/20.; vmin=np.nanmin(xx3)-dv ; vmax=np.nanmax(xx3)+2*dv
  xstar=np.arange(vmin,vmax,dv)
  ystar=ConfInter(xx3[tmp], yy0[2][tmp], slope, intercept, xstar)
  ax.plot(xstar,xstar*slope+intercept,color='grey',lw=1,label='N='+str('%i' %np.sum(tmp))+' r='+str('%.2f' %r_value))
  ax.plot(xstar,xstar*slope+intercept,lw=0,label='slope='+str(slope)+' interc='+str('%.2f' %intercept)+' p='+str('%.3f'%p_value))
  ###~~~~~~~~~~~~~~~~~~~~~~~
  if xind[loop]==18:
    tmp=(xx22!=xx22)
    ax.errorbar(xx3[tmp],yy0[2][tmp],yerr=yerr[:,tmp],color=blue_color,elinewidth=0.3,marker='o',markersize=8,mew=0.4,mfc='None',mec=blue_color,lw=0,)
    ax.errorbar(xx22,yy0[2],yerr=yerr,color='k',elinewidth=0.3,marker='o',markersize=8,mew=0.4,mfc='None',mec='k',lw=0,)
  else:
    ax.errorbar(xx3,yy0[2],yerr=yerr,color='k',elinewidth=0.3,marker='o',markersize=8,mew=0.4,mfc='None',mec='k',lw=0,)
  ###~~~~~~~~~~~~~~~~~~~~~~~
  ax.legend(loc=0,fontsize=8)
  for label in ax.get_xticklabels():label.set_fontsize(15)
  for label in ax.get_yticklabels():label.set_fontsize(15)
  ax.set_xlabel(xlabels[loop], fontsize=15)
  ax.set_ylabel('Dh', fontsize=15)
  ax.set_ylim(0,1.75)
###~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
###~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
plt.subplots_adjust(top=0.95,bottom=0.05,left=0.05,wspace=0.2,hspace=0.3,right=0.95)
#fig.savefig('regress_data.png',dpi=300);plt.close(fig)
plt.show()
