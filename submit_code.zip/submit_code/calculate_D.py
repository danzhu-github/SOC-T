#!/usr/bin/env python
import numpy as np
import matplotlib as mpl
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit


yrstart=1961 ; yrend=1991 ; nummon=12 ; all7dep=5

##########################################################
def expo(xx,kk):
  return np.exp(-kk*xx)

###############################################################################
####### load the post-processed files of Russian soil temperature dataset #####
###############################################################################
stn_id=np.load(    'XX/INPUT/stn_id.npy')
stn_lon=np.load(   'XX/INPUT/stn_lon.npy')
stn_lat=np.load(   'XX/INPUT/stn_lat.npy')
Data_Tsoil=np.load('XX/INPUT/Data_Tsoil.npy') #Dimensions: 263 sites; 120 years (1881-2000); 12 months; 13 depths (0.02,0.05,0.1,0.15,0.2,0.4,0.6,0.8,1.2,1.6,2.0,2.4,3.2)

###############################################################################
####### Data filtering  #######################################################
###############################################################################
depth=[0.02,0.05,0.1,0.15,0.2,0.4,0.6,0.8,1.2,1.6,2.0,2.4,3.2]
Data_Tsoil_use=Data_Tsoil[:,(yrstart-1881):(yrend-1881)]*1.
dep7=np.array([0.2,0.4,0.8,1.2,1.6,2.4,3.2]) #use only 7 depths where most of the measurements were taken
Data_dep7=np.concatenate((Data_Tsoil_use[:,:,:,4:6],Data_Tsoil_use[:,:,:,7:10],Data_Tsoil_use[:,:,:,11:13]),axis=3)
###~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
tmp=(Data_dep7==Data_dep7)
tmp1=np.where(np.sum(tmp,axis=2)>=nummon,1,np.nan)
print 'exclude sites*year if available month <',nummon, np.nansum(tmp1,axis=(0,1))
tmp2=np.where(np.nansum(tmp1,axis=2)>=all7dep,1,np.nan)
print 'exclude sites*year if available depth < ',all7dep, np.nansum(tmp2,axis=(0,1))
tmp0=np.where((tmp1[:,:,0]==tmp1[:,:,0]),1,np.nan)
print '0.2m must be valid',np.nansum(tmp0*tmp2,axis=(0,1))
Data_dep7_eff=np.transpose(np.transpose(Data_dep7,(2,3,0,1))*np.transpose(tmp1,(2,0,1))*tmp2*tmp0,(2,3,0,1))
print 'effective sites',np.sum(np.sum((Data_dep7_eff==Data_dep7_eff),axis=(1,2,3))>0)

###############################################################################
####### calculate thermal diffusivity #########################################
###############################################################################
A_dep7=np.max(Data_dep7_eff,axis=2)-np.min(Data_dep7_eff,axis=2)  #seasonal-cycle amplitude
Anorm_dep7=np.transpose(np.transpose(A_dep7,(2,0,1))/A_dep7[:,:,0],(1,2,0))  #relative amplitude
###~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
popt=np.zeros((263,yrend-yrstart))*np.nan ; pcov=np.zeros((263,yrend-yrstart,2))*np.nan
for ii in range(263):
  for jj in range(yrend-yrstart):
    tmp=Anorm_dep7[ii,jj,:]
    if np.sum(tmp==tmp)>0:
      popt[ii,jj],pcov[ii,jj]=curve_fit(expo,dep7[tmp==tmp],tmp[tmp==tmp])
Dh=(2*3.14/86400/365.)/2/popt**2*10**6
print np.sum(popt==popt),np.sum(Dh==Dh)
